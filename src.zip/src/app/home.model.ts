import { PatientLocation } from './location.model';


export class Home {
  constructor(
    public last_phc_data:any,
    public last_phone_data:any,
    public last_visit_data:any,
  
    
    
  ) {}
}