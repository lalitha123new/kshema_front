import { PatientLocation } from './location.model';

export class Login {
  constructor(
    public loginData: any,
    public swData : any ,
    public groupData: any ,
    
  ) {}
}