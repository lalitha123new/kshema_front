import { PatientLocation } from './location.model';

export class Districts {
  constructor(
    
    public district_master_id: number,
    public district_name: string
  
   
    
  ) {}
}