import { PatientLocation } from './location.model';

export class UDID {
  constructor(
    public udid_uuid_data: any,
    public latest_udid_data: string,
    
  ) {}
}