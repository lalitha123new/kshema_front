import { PatientLocation } from './location.model';


export class History {
  constructor(
    public history_data:any,
    public notes_data:any,
    public pat_data:any,
    public task_data:any
    
    
  ) {}
}