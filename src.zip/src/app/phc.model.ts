import { PatientLocation } from './location.model';

export class Phcs {
  constructor(
    
    public phc_id: number,
    public phc_name: string
  
   
    
  ) {}
}