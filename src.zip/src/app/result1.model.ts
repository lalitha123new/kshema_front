import { PatientLocation } from './location.model';

export class Result1 {
  constructor(
    
   
    public patient_id : number ,
   
  ) {}
}