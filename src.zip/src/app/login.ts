export interface Login1
{
    username:string,
    password:string
}