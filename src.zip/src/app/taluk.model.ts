import { PatientLocation } from './location.model';

export class Taluks {
  constructor(
    
    public taluka_master_id: number,
    public taluka_name: string,
    public taluka_details : string ,
    public createdAt: any ,
   
    
  ) {}
}